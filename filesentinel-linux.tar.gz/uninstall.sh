#!/bin/bash

set -e

BINARY_NAME="filesentinel"
INSTALL_DIR="/usr/local/bin"

echo "=== Désinstallation de FileSentinel ==="

# Vérifier les droits administrateur
if [ "$EUID" -ne 0 ]; then
    echo "[ERREUR] Ce script doit être exécuté en tant qu'administrateur."
    echo "         Relancez avec : sudo ./uninstall.sh"
    exit 1
fi

# Vérifier que le binaire est installé
if [ ! -f "$INSTALL_DIR/$BINARY_NAME" ]; then
    echo "[!] filesentinel n'est pas installé dans $INSTALL_DIR"
    exit 0
fi

# Supprimer le binaire
echo "[...] Suppression de $INSTALL_DIR/$BINARY_NAME..."
rm -f "$INSTALL_DIR/$BINARY_NAME"

echo "[OK] filesentinel désinstallé avec succès."