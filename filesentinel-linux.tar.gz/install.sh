#!/bin/bash

set -e

BINARY_NAME="filesentinel"
INSTALL_DIR="/usr/local/bin"

echo "=== Installation de FileSentinel ==="

# Vérifier que le binaire est présent
if [ ! -f "$BINARY_NAME" ]; then
    echo "[ERREUR] Le fichier '$BINARY_NAME' est introuvable."
    echo "         Assurez-vous que le binaire est dans le même dossier que ce script."
    exit 1
fi

# Vérifier les droits administrateur
if [ "$EUID" -ne 0 ]; then
    echo "[ERREUR] Ce script doit être exécuté en tant qu'administrateur."
    echo "         Relancez avec : sudo ./install.sh"
    exit 1
fi

# Copier le binaire
echo "[...] Installation dans $INSTALL_DIR..."
cp "$BINARY_NAME" "$INSTALL_DIR/$BINARY_NAME"
chmod +x "$INSTALL_DIR/$BINARY_NAME"

echo "[OK] filesentinel installé avec succès."
echo ""
echo "Vérifiez l'installation avec : filesentinel --version"