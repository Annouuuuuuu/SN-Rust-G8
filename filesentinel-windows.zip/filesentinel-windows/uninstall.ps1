$dest = "$env:ProgramFiles\filesentinel"

# Supprimer le dossier
if (Test-Path $dest) {
    Remove-Item $dest -Recurse -Force
    Write-Host "[OK] Fichiers supprimes"
} else {
    Write-Host "[!] filesentinel n'est pas installe"
}

# Retirer du PATH
$current = [Environment]::GetEnvironmentVariable("Path", "Machine")
if ($current -like "*$dest*") {
    $newPath = ($current -split ";" | Where-Object { $_ -ne $dest }) -join ";"
    [Environment]::SetEnvironmentVariable("Path", $newPath, "Machine")
    Write-Host "[OK] Retire du PATH"
}

Write-Host "[OK] filesentinel desinstalle avec succes"
pause