$dest = "$env:ProgramFiles\filesentinel"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item "filesentinel.exe" -Destination $dest

$current = [Environment]::GetEnvironmentVariable("Path", "Machine")
if ($current -notlike "*$dest*") {
    [Environment]::SetEnvironmentVariable("Path", "$current;$dest", "Machine")
    Write-Host "[OK] filesentinel installe et ajoute au PATH"
} else {
    Write-Host "[OK] filesentinel installe (deja dans le PATH)"
}

Write-Host "Relancez votre terminal pour que le PATH soit pris en compte."
pause